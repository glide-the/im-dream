# Kastention UI规范 v3.1 可编辑源文件

正文：docs/prd/mobile-app/ui-guidelines/README.md。
图形定义与PDF导出：同目录export_pdf.py；assets为可编辑SVG。

名称修订采用Kastention与卡片结构；原19页结构、17幅示意图及视觉规则保持。
解压后沿仓库相对路径执行 `python3 docs/prd/mobile-app/ui-guidelines/export_pdf.py`。
Python需要reportlab，中文正文字体通过INK_UI_BODY_FONT指定本机可用TrueType字体；原中文手写字体和tokens.css已附。
包内文档引用保留仓库路径，完整业务资料在原仓库中查阅。
原v3.0 PDF和源文件包保留历史。旧版评审/验证记录描述原交付，名称修订证据归app-brand-rename-20261102.md。
